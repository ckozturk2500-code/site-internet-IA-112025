from flask import Blueprint, request, jsonify, session
from datetime import datetime
from src.models.user import db, User, Progress, QuizScore

progress_bp = Blueprint('progress', __name__, url_prefix='/api/progress')

def require_auth(f):
    """Décorateur pour vérifier l'authentification"""
    def decorated_function(*args, **kwargs):
        if not session.get('user_id'):
            return jsonify({'error': 'Non authentifié'}), 401
        return f(*args, **kwargs)
    decorated_function.__name__ = f.__name__
    return decorated_function

@progress_bp.route('/module/<module_id>', methods=['POST'])
@require_auth
def complete_module(module_id):
    """Marquer un module comme complété"""
    try:
        user_id = session.get('user_id')
        
        # Vérifier si déjà complété
        existing = Progress.query.filter_by(
            user_id=user_id,
            module_id=module_id
        ).first()
        
        if existing:
            return jsonify({'message': 'Module déjà complété'}), 200
        
        # Créer la progression
        progress = Progress(
            user_id=user_id,
            module_id=module_id
        )
        
        db.session.add(progress)
        db.session.commit()
        
        return jsonify({
            'message': 'Module complété',
            'progress': progress.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@progress_bp.route('/quiz', methods=['POST'])
@require_auth
def submit_quiz():
    """Soumettre un score de quiz"""
    try:
        user_id = session.get('user_id')
        data = request.get_json()
        
        required_fields = ['quizId', 'score', 'total']
        for field in required_fields:
            if field not in data:
                return jsonify({'error': f'Le champ {field} est obligatoire'}), 400
        
        # Créer le score
        quiz_score = QuizScore(
            user_id=user_id,
            quiz_id=data['quizId'],
            score=data['score'],
            total=data['total'],
            time_spent=data.get('timeSpent')
        )
        
        db.session.add(quiz_score)
        
        # Marquer le quiz comme complété dans la progression
        existing_progress = Progress.query.filter_by(
            user_id=user_id,
            module_id=data['quizId']
        ).first()
        
        if not existing_progress:
            progress = Progress(
                user_id=user_id,
                module_id=data['quizId']
            )
            db.session.add(progress)
        
        db.session.commit()
        
        return jsonify({
            'message': 'Score enregistré',
            'quizScore': quiz_score.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@progress_bp.route('/user', methods=['GET'])
@require_auth
def get_user_progress():
    """Récupérer la progression de l'utilisateur connecté"""
    try:
        user_id = session.get('user_id')
        user = User.query.get(user_id)
        
        if not user:
            return jsonify({'error': 'Utilisateur non trouvé'}), 404
        
        completed_modules = [p.module_id for p in user.progress]
        quiz_scores = [q.to_dict() for q in user.quiz_scores]
        
        return jsonify({
            'completedModules': completed_modules,
            'quizScores': quiz_scores
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

