from flask import Blueprint, request, jsonify, session
from datetime import datetime
from src.models.user import db, User, AccessCode, Admin

auth_bp = Blueprint('auth', __name__, url_prefix='/api/auth')

@auth_bp.route('/register', methods=['POST'])
def register():
    """Inscription d'un nouvel utilisateur"""
    try:
        data = request.get_json()
        
        # Validation des données
        required_fields = ['firstName', 'lastName', 'email', 'accessCode']
        for field in required_fields:
            if not data.get(field):
                return jsonify({'error': f'Le champ {field} est obligatoire'}), 400
        
        # Vérifier si l'email existe déjà
        existing_user = User.query.filter_by(email=data['email']).first()
        if existing_user:
            return jsonify({'error': 'Cet email est déjà utilisé'}), 400
        
        # Vérifier le code d'accès
        access_code = AccessCode.query.filter_by(code=data['accessCode'].upper()).first()
        if not access_code:
            return jsonify({'error': 'Code d\'accès invalide'}), 400
        
        if access_code.is_used:
            return jsonify({'error': 'Ce code d\'accès a déjà été utilisé'}), 400
        
        # Créer l'utilisateur
        new_user = User(
            first_name=data['firstName'],
            last_name=data['lastName'],
            email=data['email'],
            access_code=data['accessCode'].upper()
        )
        
        # Marquer le code comme utilisé
        access_code.is_used = True
        access_code.used_by_email = data['email']
        access_code.used_at = datetime.utcnow()
        
        db.session.add(new_user)
        db.session.commit()
        
        # Créer la session
        session['user_id'] = new_user.id
        session['is_admin'] = False
        
        return jsonify({
            'message': 'Inscription réussie',
            'user': new_user.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@auth_bp.route('/login', methods=['POST'])
def login():
    """Connexion d'un utilisateur"""
    try:
        data = request.get_json()
        
        if not data.get('email') or not data.get('accessCode'):
            return jsonify({'error': 'Email et code d\'accès requis'}), 400
        
        # Rechercher l'utilisateur
        user = User.query.filter_by(
            email=data['email'],
            access_code=data['accessCode'].upper()
        ).first()
        
        if not user:
            return jsonify({'error': 'Email ou code d\'accès incorrect'}), 401
        
        if not user.is_active:
            return jsonify({'error': 'Compte désactivé'}), 403
        
        # Mettre à jour la dernière connexion
        user.last_login = datetime.utcnow()
        db.session.commit()
        
        # Créer la session
        session['user_id'] = user.id
        session['is_admin'] = False
        
        return jsonify({
            'message': 'Connexion réussie',
            'user': user.to_dict()
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@auth_bp.route('/admin/login', methods=['POST'])
def admin_login():
    """Connexion administrateur"""
    try:
        data = request.get_json()
        
        if not data.get('username') or not data.get('password'):
            return jsonify({'error': 'Nom d\'utilisateur et mot de passe requis'}), 400
        
        # Rechercher l'admin
        admin = Admin.query.filter_by(username=data['username']).first()
        
        if not admin or not admin.check_password(data['password']):
            return jsonify({'error': 'Identifiants incorrects'}), 401
        
        # Créer la session
        session['admin_id'] = admin.id
        session['is_admin'] = True
        
        return jsonify({
            'message': 'Connexion administrateur réussie',
            'admin': admin.to_dict()
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@auth_bp.route('/logout', methods=['POST'])
def logout():
    """Déconnexion"""
    session.clear()
    return jsonify({'message': 'Déconnexion réussie'}), 200

@auth_bp.route('/me', methods=['GET'])
def get_current_user():
    """Récupérer l'utilisateur connecté"""
    try:
        if session.get('is_admin'):
            admin = Admin.query.get(session.get('admin_id'))
            if admin:
                return jsonify({
                    'isAdmin': True,
                    'user': admin.to_dict()
                }), 200
        
        user_id = session.get('user_id')
        if not user_id:
            return jsonify({'error': 'Non authentifié'}), 401
        
        user = User.query.get(user_id)
        if not user:
            return jsonify({'error': 'Utilisateur non trouvé'}), 404
        
        return jsonify({
            'isAdmin': False,
            'user': user.to_dict()
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

