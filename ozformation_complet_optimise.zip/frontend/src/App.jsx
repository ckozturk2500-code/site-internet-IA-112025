import { useState, useEffect, createContext } from 'react'
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom'
import './App.css'

// Pages
import HomePage from './pages/HomePage'
import LoginPage from './pages/LoginPage'
import RegisterPage from './pages/RegisterPage'
import DashboardPage from './pages/DashboardPage'
import ModulePage from './pages/ModulePage'
import QuizPage from './pages/QuizPage'
import CertificatePage from './pages/CertificatePage'
import AdminLoginPage from './pages/AdminLoginPage'
import AdminDashboardPage from './pages/AdminDashboardPage'

// Créer le contexte utilisateur
export const UserContext = createContext(null)

function App() {
  const [user, setUser] = useState(null)
  const [isAdmin, setIsAdmin] = useState(false)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const storedUser = localStorage.getItem('user')
    const storedAdmin = localStorage.getItem('isAdmin')
    
    if (storedUser) {
      setUser(JSON.parse(storedUser))
    }
    
    if (storedAdmin) {
      setIsAdmin(JSON.parse(storedAdmin))
    }
    
    setLoading(false)
  }, [])

  const handleLogin = (userData, adminStatus = false) => {
    setUser(userData)
    setIsAdmin(adminStatus)
    localStorage.setItem('user', JSON.stringify(userData))
    localStorage.setItem('isAdmin', JSON.stringify(adminStatus))
  }

  const handleLogout = () => {
    setUser(null)
    setIsAdmin(false)
    localStorage.removeItem('user')
    localStorage.removeItem('isAdmin')
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
        <div className="text-center">
          <div className="animate-spin rounded-full h-16 w-16 border-b-4 border-indigo-600 mx-auto"></div>
          <p className="mt-4 text-gray-600 font-medium">Chargement...</p>
        </div>
      </div>
    )
  }

  return (
    <UserContext.Provider value={{ user, setUser, isAdmin, setIsAdmin, logout: handleLogout }}>
      <Router>
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route 
            path="/login" 
            element={user ? <Navigate to="/dashboard" /> : <LoginPage onLogin={handleLogin} />} 
          />
          <Route 
            path="/register" 
            element={user ? <Navigate to="/dashboard" /> : <RegisterPage />} 
          />
          <Route 
            path="/dashboard" 
            element={user && !isAdmin ? <DashboardPage /> : <Navigate to="/login" />} 
          />
          <Route 
            path="/module/:moduleId" 
            element={user && !isAdmin ? <ModulePage /> : <Navigate to="/login" />} 
          />
          <Route 
            path="/quiz/:quizId" 
            element={user && !isAdmin ? <QuizPage /> : <Navigate to="/login" />} 
          />
          <Route 
            path="/certificate" 
            element={user && !isAdmin ? <CertificatePage /> : <Navigate to="/login" />} 
          />
          <Route 
            path="/admin/login" 
            element={isAdmin ? <Navigate to="/admin/dashboard" /> : <AdminLoginPage onLogin={handleLogin} />} 
          />
          <Route 
            path="/admin/dashboard" 
            element={isAdmin ? <AdminDashboardPage user={user} onLogout={handleLogout} /> : <Navigate to="/admin/login" />} 
          />
          <Route path="*" element={<Navigate to="/" />} />
        </Routes>
      </Router>
    </UserContext.Provider>
  )
}

export default App

