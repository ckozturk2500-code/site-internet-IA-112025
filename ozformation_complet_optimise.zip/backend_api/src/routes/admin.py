from flask import Blueprint, request, jsonify, session
from datetime import datetime
import random
import string
from src.models.user import db, User, AccessCode, Admin, QuizScore

admin_bp = Blueprint('admin', __name__, url_prefix='/api/admin')

def require_admin(f):
    """Décorateur pour vérifier l'authentification admin"""
    def decorated_function(*args, **kwargs):
        if not session.get('is_admin') or not session.get('admin_id'):
            return jsonify({'error': 'Accès non autorisé'}), 403
        return f(*args, **kwargs)
    decorated_function.__name__ = f.__name__
    return decorated_function

@admin_bp.route('/users', methods=['GET'])
@require_admin
def get_all_users():
    """Récupérer tous les utilisateurs"""
    try:
        users = User.query.all()
        return jsonify({
            'users': [user.to_dict() for user in users]
        }), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@admin_bp.route('/users/<int:user_id>', methods=['GET'])
@require_admin
def get_user(user_id):
    """Récupérer un utilisateur spécifique"""
    try:
        user = User.query.get(user_id)
        if not user:
            return jsonify({'error': 'Utilisateur non trouvé'}), 404
        
        return jsonify({'user': user.to_dict()}), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@admin_bp.route('/codes', methods=['GET'])
@require_admin
def get_all_codes():
    """Récupérer tous les codes d'accès"""
    try:
        codes = AccessCode.query.all()
        return jsonify({
            'codes': [code.to_dict() for code in codes]
        }), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@admin_bp.route('/codes/generate', methods=['POST'])
@require_admin
def generate_code():
    """Générer un nouveau code d'accès"""
    try:
        # Générer un code unique
        while True:
            code = 'OZLIA' + ''.join(random.choices(string.digits, k=6))
            existing = AccessCode.query.filter_by(code=code).first()
            if not existing:
                break
        
        new_code = AccessCode(code=code)
        db.session.add(new_code)
        db.session.commit()
        
        return jsonify({
            'message': 'Code généré avec succès',
            'code': new_code.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@admin_bp.route('/stats', methods=['GET'])
@require_admin
def get_stats():
    """Récupérer les statistiques globales"""
    try:
        total_users = User.query.count()
        total_codes = AccessCode.query.count()
        used_codes = AccessCode.query.filter_by(is_used=True).count()
        
        # Progression moyenne
        users = User.query.all()
        if users:
            total_progress = sum(len(user.progress) for user in users)
            avg_progress = total_progress / len(users) if len(users) > 0 else 0
        else:
            avg_progress = 0
        
        # Taux de réussite aux quiz
        quiz_scores = QuizScore.query.all()
        quiz_stats = {}
        for quiz in quiz_scores:
            if quiz.quiz_id not in quiz_stats:
                quiz_stats[quiz.quiz_id] = {'total': 0, 'passed': 0}
            quiz_stats[quiz.quiz_id]['total'] += 1
            if quiz.score >= (quiz.total * 0.6):
                quiz_stats[quiz.quiz_id]['passed'] += 1
        
        return jsonify({
            'totalUsers': total_users,
            'totalCodes': total_codes,
            'usedCodes': used_codes,
            'avgProgress': round(avg_progress, 2),
            'quizStats': quiz_stats
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@admin_bp.route('/users/<int:user_id>/toggle', methods=['POST'])
@require_admin
def toggle_user_status(user_id):
    """Activer/désactiver un utilisateur"""
    try:
        user = User.query.get(user_id)
        if not user:
            return jsonify({'error': 'Utilisateur non trouvé'}), 404
        
        user.is_active = not user.is_active
        db.session.commit()
        
        return jsonify({
            'message': f'Utilisateur {"activé" if user.is_active else "désactivé"}',
            'user': user.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

